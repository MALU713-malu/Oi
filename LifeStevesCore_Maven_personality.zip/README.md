# LifeStevesCore 3.1.0

Recursos incluídos:
- ritual com agachar + maçã encantada
- renomeio real por Name Tag
- `/rn lifesteve <nome>`
- `/lifesteves perso <personalidade>`
- comando de follow e parar de seguir
- tropas com tag lateral no nome
- IA com personalidades
- dono tratado como "mestre"
- construção com fumaça + giro por 30 segundos e paste depois
- inventário
- armadura automática
- combate com clava / lança / corpo a corpo

Personnalidades:
- Raivoso
- Amigável
- Carinhoso
- Quieto
- Depressivo
- Alegre
- Confuso

O modelo tenta não falar sobre morte e não usa memória de ter morrido.
