package me.malu.lifestevescore;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.session.ClipboardHolder;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.api.trait.trait.SkinTrait;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public final class LifeStevesCorePlugin extends JavaPlugin implements Listener, TabExecutor {
    private final Map<UUID, LifeSteveProfile> profiles = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> buildTasks = new ConcurrentHashMap<>();
    private final PlainTextComponentSerializer plain = PlainTextComponentSerializer.plainText();

    private File profilesFile;
    private File skinsRoot;
    private File buildsRoot;
    private OpenRouterService openRouter;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        setupFolders();
        loadProfiles();

        openRouter = new OpenRouterService(
                getConfig().getString("openrouter.api-key", ""),
                getConfig().getString("openrouter.base-url", "https://openrouter.ai/api/v1/chat/completions"),
                getConfig().getString("openrouter.model", "openai/gpt-4o-mini"),
                this
        );

        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("lifesteves")).setExecutor(this);
        Objects.requireNonNull(getCommand("lifesteves")).setTabCompleter(this);
        Objects.requireNonNull(getCommand("tropa")).setExecutor(this);
        Objects.requireNonNull(getCommand("tropa")).setTabCompleter(this);
        Objects.requireNonNull(getCommand("rn")).setExecutor(this);
        Objects.requireNonNull(getCommand("rn")).setTabCompleter(this);

        Bukkit.getScheduler().runTaskTimer(this, this::tickLifeSteves, 20L, 20L);
    }

    @Override
    public void onDisable() {
        for (BukkitTask task : buildTasks.values()) {
            if (task != null) task.cancel();
        }
        buildTasks.clear();
        saveProfiles();
    }

    private void setupFolders() {
        if (!getDataFolder().exists()) {
            getDataFolder().mkdirs();
        }
        skinsRoot = new File(getDataFolder(), "skins");
        buildsRoot = new File(getDataFolder(), "builds");
        skinsRoot.mkdirs();
        buildsRoot.mkdirs();

        profilesFile = new File(getDataFolder(), "profiles.yml");
        if (!profilesFile.exists()) {
            try { profilesFile.createNewFile(); } catch (IOException e) { getLogger().severe("Não foi possível criar profiles.yml: " + e.getMessage()); }
        }
    }

    private void loadProfiles() {
        profiles.clear();
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(profilesFile);
        ConfigurationSection root = yaml.getConfigurationSection("profiles");
        if (root == null) return;

        for (String key : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(key);
            if (section == null) continue;
            try {
                LifeSteveProfile profile = LifeSteveProfile.fromSection(UUID.fromString(key), section);
                if (profile.personality() == null) {
                    profile.setPersonality(Personality.random());
                }
                profiles.put(profile.npcId(), profile);
                ensureNpcFolders(profile.npcId());
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveProfiles() {
        YamlConfiguration yaml = new YamlConfiguration();
        ConfigurationSection root = yaml.createSection("profiles");
        for (LifeSteveProfile profile : profiles.values()) {
            ConfigurationSection section = root.createSection(profile.npcId().toString());
            profile.save(section);
        }
        try {
            yaml.save(profilesFile);
        } catch (IOException e) {
            getLogger().severe("Erro salvando profiles.yml: " + e.getMessage());
        }
    }

    private void ensureNpcFolders(UUID npcId) {
        new File(skinsRoot, npcId.toString()).mkdirs();
        new File(buildsRoot, npcId.toString()).mkdirs();
    }

    private boolean hasCitizens() {
        return getServer().getPluginManager().getPlugin("Citizens") != null && CitizensAPI.getNPCRegistry() != null;
    }

    private NPC npcById(UUID id) {
        if (!hasCitizens()) return null;
        return CitizensAPI.getNPCRegistry().getByUniqueId(id);
    }

    private LifeSteveProfile profileFor(NPC npc) {
        return profiles.computeIfAbsent(npc.getUniqueId(), id -> new LifeSteveProfile(id));
    }

    private boolean isApple(ItemStack item) {
        return item != null && item.getType() == Material.ENCHANTED_GOLDEN_APPLE;
    }

    private boolean isNameTag(ItemStack item) {
        return item != null && item.getType() == Material.NAME_TAG;
    }

    private boolean canUse(LifeSteveProfile profile, Player player) {
        return profile.owner() == null || profile.owner().equals(player.getUniqueId()) || player.isOp();
    }

    private void consumeOne(Player player, EquipmentSlot slot) {
        ItemStack stack = slot == EquipmentSlot.OFF_HAND ? player.getInventory().getItemInOffHand() : player.getInventory().getItemInMainHand();
        if (stack == null || stack.getAmount() <= 1) {
            if (slot == EquipmentSlot.OFF_HAND) player.getInventory().setItemInOffHand(null);
            else player.getInventory().setItemInMainHand(null);
            return;
        }
        stack.setAmount(stack.getAmount() - 1);
        if (slot == EquipmentSlot.OFF_HAND) player.getInventory().setItemInOffHand(stack);
        else player.getInventory().setItemInMainHand(stack);
    }

    private String normalizeName(String input) {
        if (input == null) return "";
        return ChatColor.stripColor(input).trim();
    }

    private String stripTroopPrefix(String name) {
        if (name == null) return "";
        return name.replaceAll("^\\[[^\\]]+\\]\\s*", "").trim();
    }

    private String formatName(LifeSteveProfile profile) {
        String base = profile.displayName().isBlank() ? "LifeSteve" : profile.displayName().trim();
        if (profile.troopName().isBlank()) return base;
        return "[" + profile.troopName().trim() + "] " + base;
    }

    private void applyDisplay(NPC npc, LifeSteveProfile profile) {
        String formatted = formatName(profile);
        npc.setName(formatted);
        if (npc.getEntity() instanceof LivingEntity living) {
            living.setCustomName(formatted);
            living.setCustomNameVisible(true);
        }
    }

    private void applySkin(NPC npc, LifeSteveProfile profile) {
        if (!npc.hasTrait(SkinTrait.class)) npc.addTrait(SkinTrait.class);
        SkinTrait skin = npc.getTrait(SkinTrait.class);
        if (profile.skin() == null || profile.skin().isBlank()) return;
        try {
            skin.setSkinName(profile.skin());
        } catch (Exception e) {
            getLogger().warning("Não foi possível aplicar skin: " + e.getMessage());
        }
    }

    private void setMaxHealth(LivingEntity living, double value) {
        AttributeInstance attr = living.getAttribute(Attribute.MAX_HEALTH);
        if (attr == null) return;
        attr.setBaseValue(Math.max(2.0, value));
        if (living.getHealth() > attr.getValue()) living.setHealth(attr.getValue());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onRitual(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Zombie zombie)) return;
        Player player = event.getPlayer();
        if (!player.isSneaking()) return;
        if (!isApple(player.getInventory().getItemInMainHand())) return;

        event.setCancelled(true);
        if (!hasCitizens()) {
            player.sendMessage(color("&cCitizens não está ativo."));
            return;
        }

        NPC npc = CitizensAPI.getNPCRegistry().createNPC(EntityType.PLAYER, "LifeSteve");
        Location spawn = zombie.getLocation().clone();
        zombie.remove();
        npc.spawn(spawn);

        LifeSteveProfile profile = profileFor(npc);
        profile.setOwner(player.getUniqueId());
        profile.setDisplayName("LifeSteve");
        profile.setTroopName("");
        profile.setPersonality(Personality.random());
        profile.setHealth(getConfig().getDouble("life-steve.max-health", 40.0));
        profile.setHunger(getConfig().getInt("life-steve.default-hunger", 20));
        profile.setEmotion("neutral");
        profile.setLocation(spawn);
        profile.touch("Nascimento por ritual", getConfig().getInt("life-steve.memory-limit", 30));

        applyDisplay(npc, profile);
        applySkin(npc, profile);
        npc.setProtected(true);

        consumeOne(player, EquipmentSlot.HAND);
        saveProfiles();
        player.sendMessage(color("&aLifeSteve criado: &f" + profile.nameOrId() + " &7[" + profile.personality().label() + "]"));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onNpcInteract(PlayerInteractEntityEvent event) {
        if (!hasCitizens()) return;
        NPC npc = CitizensAPI.getNPCRegistry().getNPC(event.getRightClicked());
        if (npc == null) return;

        LifeSteveProfile profile = profileFor(npc);
        Player player = event.getPlayer();
        ItemStack item = event.getHand() == EquipmentSlot.OFF_HAND
                ? player.getInventory().getItemInOffHand()
                : player.getInventory().getItemInMainHand();

        if (player.isSneaking() && isNameTag(item)) {
            event.setCancelled(true);
            if (!canUse(profile, player)) {
                player.sendMessage(color("&cApenas o dono pode renomear este LifeSteve."));
                return;
            }

            ItemMeta meta = item.getItemMeta();
            String display = "";
            if (meta != null && meta.hasDisplayName()) {
                display = meta.getDisplayName();
            }
            display = normalizeName(display);

            if (display.isBlank()) {
                player.sendMessage(color("&eRenomeie a name tag na bigorna primeiro."));
                return;
            }

            profile.setDisplayName(display);
            profile.touch("Renomeado para " + display, getConfig().getInt("life-steve.memory-limit", 30));
            applyDisplay(npc, profile);
            saveProfiles();
            consumeOne(player, event.getHand() == EquipmentSlot.OFF_HAND ? EquipmentSlot.OFF_HAND : EquipmentSlot.HAND);
            player.sendMessage(color("&aNome alterado para &f" + display + "&a."));
            return;
        }

        if (player.isSneaking() && (item == null || item.getType().isAir())) {
            event.setCancelled(true);
            if (!canUse(profile, player)) {
                player.sendMessage(color("&cApenas o dono pode abrir o inventário."));
                return;
            }
            openInventory(player, profile);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;

        List<LifeSteveProfile> owned = nearbyOwnedProfiles(attacker.getLocation(), attacker.getUniqueId(), 20.0);
        if (owned.isEmpty()) return;

        for (LifeSteveProfile profile : owned) {
            profile.setCombatTarget(victim.getUniqueId());
            profile.setCombatUntilMillis(System.currentTimeMillis() + 20_000L);
            profile.touch("Defendendo o dono contra " + victim.getType(), getConfig().getInt("life-steve.memory-limit", 30));
        }
        saveProfiles();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!hasCitizens()) return;

        Player player = event.getPlayer();
        String message = plain.serialize(event.message()).trim();
        if (message.isBlank()) return;

        String lower = ChatColor.stripColor(message).toLowerCase(Locale.ROOT);

        TroopProfile troop = resolveTroopByMessage(lower);
        LifeSteveProfile npcProfile = resolveNpcByMessage(lower);

        if (containsStopWord(lower)) {
            if (troop != null) {
                event.setCancelled(true);
                stopTroop(troop);
                saveProfiles();
                Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&aA tropa " + troop.name() + " parou.")));
                return;
            }
            if (npcProfile != null) {
                event.setCancelled(true);
                stopNpc(npcProfile);
                saveProfiles();
                Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&a" + npcProfile.nameOrId() + " parou de seguir.")));
                return;
            }
        }

        LifeSteveProfile followNpc = resolveFollowNpcByMessage(lower);
        if (followNpc != null && containsFollowWord(lower)) {
            event.setCancelled(true);
            followNpc.setFollowTarget(player.getUniqueId());
            followNpc.setFollowUntilMillis(System.currentTimeMillis() + (getConfig().getLong("life-steve.command-duration-seconds", 60L) * 1000L));
            followNpc.touch(player.getName() + ": me siga", getConfig().getInt("life-steve.memory-limit", 30));
            saveProfiles();
            Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&a" + followNpc.nameOrId() + " agora está te seguindo.")));
            return;
        }

        if (troop != null) {
            if (lower.contains("sigam me")) {
                event.setCancelled(true);
                setTroopFollow(troop, player.getUniqueId(), getConfig().getLong("life-steve.command-duration-seconds", 60L) * 1000L);
                saveProfiles();
                Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&aA tropa " + troop.name() + " vai seguir você.")));
                return;
            }

            if (lower.contains("sigam ")) {
                event.setCancelled(true);
                String targetName = message.substring(lower.indexOf("sigam ") + 6).trim();
                Player targetPlayer = findOnlinePlayer(targetName);
                if (targetPlayer != null) {
                    setTroopFollow(troop, targetPlayer.getUniqueId(), getConfig().getLong("life-steve.command-duration-seconds", 60L) * 1000L);
                    saveProfiles();
                    Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&aA tropa " + troop.name() + " vai seguir " + targetPlayer.getName() + ".")));
                }
                return;
            }

            if (lower.contains("ataquem ")) {
                event.setCancelled(true);
                String targetName = message.substring(lower.indexOf("ataquem ") + 8).trim();
                Player targetPlayer = findOnlinePlayer(targetName);
                if (targetPlayer != null) {
                    setTroopCombat(troop, targetPlayer.getUniqueId(), getConfig().getLong("life-steve.command-duration-seconds", 60L) * 1000L);
                    saveProfiles();
                    Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&aA tropa " + troop.name() + " vai atacar " + targetPlayer.getName() + ".")));
                }
                return;
            }

            if (lower.contains("matem pra mim ")) {
                event.setCancelled(true);
                handleTroopHunt(player, troop, message, lower);
                return;
            }
        }

        if (npcProfile == null) return;

        if (containsFollowWord(lower) && lower.contains(npcProfile.nameOrId().toLowerCase(Locale.ROOT))) {
            event.setCancelled(true);
            npcProfile.setFollowTarget(player.getUniqueId());
            npcProfile.setFollowUntilMillis(System.currentTimeMillis() + (getConfig().getLong("life-steve.command-duration-seconds", 60L) * 1000L));
            npcProfile.touch(player.getName() + ": follow", getConfig().getInt("life-steve.memory-limit", 30));
            saveProfiles();
            Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&a" + npcProfile.nameOrId() + " agora está te seguindo.")));
            return;
        }

        if (containsBuildWord(lower)) {
            event.setCancelled(true);
            profileBuildResponse(player, npcProfile);
            return;
        }

        if (containsAttackWord(lower)) {
            LivingEntity target = findNearestTarget(player.getLocation(), 12.0, npcProfile.owner());
            if (target == null) {
                event.setCancelled(true);
                Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&eNão achei um alvo próximo.")));
                return;
            }
            event.setCancelled(true);
            npcProfile.setCombatTarget(target.getUniqueId());
            npcProfile.setCombatUntilMillis(System.currentTimeMillis() + (getConfig().getLong("life-steve.command-duration-seconds", 60L) * 1000L));
            npcProfile.touch(player.getName() + ": " + message, getConfig().getInt("life-steve.memory-limit", 30));
            saveProfiles();
            Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&a" + npcProfile.nameOrId() + " vai atacar.")));
            return;
        }

        event.setCancelled(true);
        npcProfile.addMemory(player.getName() + ": " + message, getConfig().getInt("life-steve.memory-limit", 30));
        if (isAffectionate(lower) && npcProfile.personality() == Personality.DEPRESSIVO) {
            npcProfile.addAffectionPoints(1);
            if (npcProfile.affectionPoints() >= 100) {
                npcProfile.setPersonality(Personality.ALEGRE);
                npcProfile.setAffectionPoints(0);
                npcProfile.touch("Mudou de depressivo para alegre por carinho", getConfig().getInt("life-steve.memory-limit", 30));
            }
        }
        saveProfiles();

        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            String response = openRouter.reply(npcProfile, message);
            Bukkit.getScheduler().runTask(this, () -> {
                npcProfile.addMemory(npcProfile.nameOrId() + ": " + response, getConfig().getInt("life-steve.memory-limit", 30));
                saveProfiles();
                player.sendMessage(color("&a" + npcProfile.nameOrId() + " &7» &f" + response));
            });
        });
    }

    private boolean containsFollowWord(String lower) {
        return lower.contains("me siga") || lower.contains("segue") || lower.contains("siga");
    }

    private boolean containsStopWord(String lower) {
        return lower.contains("pare") || lower.contains("nao me siga mais") || lower.contains("não me siga mais") || lower.contains("pare de seguir");
    }

    private boolean containsAttackWord(String lower) {
        return lower.contains("bate nele") || lower.contains("atacar") || lower.contains("ataque") || lower.contains("luta") || lower.contains("lutar");
    }

    private boolean containsBuildWord(String lower) {
        return lower.contains("constru") || lower.contains("build");
    }

    private boolean isAffectionate(String lower) {
        return lower.contains("carinho") || lower.contains("querido") || lower.contains("amigo") || lower.contains("amo") || lower.contains("obrigado") || lower.contains("bonito") || lower.contains("fofo") || lower.contains("legal");
    }

    private void profileBuildResponse(Player player, LifeSteveProfile profile) {
        saveProfiles();
        Bukkit.getScheduler().runTask(this, () -> player.sendMessage(color("&e" + profile.nameOrId() + " vai construir se houver schematic na pasta dele.")));
    }

    private void stopNpc(LifeSteveProfile profile) {
        profile.setFollowTarget(null);
        profile.setFollowUntilMillis(0L);
        profile.setCombatTarget(null);
        profile.setCombatUntilMillis(0L);
        NPC npc = npcById(profile.npcId());
        if (npc != null && npc.isSpawned()) {
            npc.getNavigator().cancelNavigation();
        }
    }

    private void stopTroop(TroopProfile troop) {
        for (UUID npcId : troop.members()) {
            LifeSteveProfile profile = profiles.get(npcId);
            if (profile != null) {
                stopNpc(profile);
            }
        }
    }

    private LifeSteveProfile resolveFollowNpcByMessage(String lower) {
        for (LifeSteveProfile profile : sortedProfilesByNameLength()) {
            String name = stripTroopPrefix(profile.displayName()).toLowerCase(Locale.ROOT);
            if (name.isBlank()) continue;
            if (lower.startsWith("me siga ") && lower.contains(name)) return profile;
            if (lower.contains(name + " me siga") || lower.contains(name + " siga")) return profile;
        }
        return null;
    }

    private LifeSteveProfile resolveNpcByMessage(String lower) {
        for (LifeSteveProfile profile : sortedProfilesByNameLength()) {
            String name = stripTroopPrefix(profile.displayName()).toLowerCase(Locale.ROOT);
            if (name.isBlank()) continue;
            if (lower.contains(name)) return profile;
        }
        return null;
    }

    private List<LifeSteveProfile> sortedProfilesByNameLength() {
        List<LifeSteveProfile> list = new ArrayList<>(profiles.values());
        list.sort((a, b) -> Integer.compare(stripTroopPrefix(b.displayName()).length(), stripTroopPrefix(a.displayName()).length()));
        return list;
    }

    private TroopProfile resolveTroopByMessage(String lower) {
        Map<String, TroopProfile> troops = collectTroops();
        List<TroopProfile> ordered = new ArrayList<>(troops.values());
        ordered.sort((a, b) -> Integer.compare(b.name().length(), a.name().length()));
        for (TroopProfile troop : ordered) {
            String troopName = troop.name().toLowerCase(Locale.ROOT);
            if (lower.contains(troopName)) return troop;
        }
        return null;
    }

    private Map<String, TroopProfile> collectTroops() {
        Map<String, TroopProfile> troops = new java.util.HashMap<>();
        for (LifeSteveProfile profile : profiles.values()) {
            if (profile.troopName().isBlank()) continue;
            TroopProfile troop = troops.computeIfAbsent(profile.troopName().toLowerCase(Locale.ROOT), k -> new TroopProfile(profile.troopName()));
            troop.members().add(profile.npcId());
        }
        return troops;
    }

    private void setTroopFollow(TroopProfile troop, UUID target, long durationMs) {
        long until = System.currentTimeMillis() + durationMs;
        for (UUID npcId : troop.members()) {
            LifeSteveProfile profile = profiles.get(npcId);
            if (profile == null) continue;
            profile.setFollowTarget(target);
            profile.setFollowUntilMillis(until);
            profile.setCombatTarget(null);
        }
    }

    private void setTroopCombat(TroopProfile troop, UUID target, long durationMs) {
        long until = System.currentTimeMillis() + durationMs;
        for (UUID npcId : troop.members()) {
            LifeSteveProfile profile = profiles.get(npcId);
            if (profile == null) continue;
            profile.setCombatTarget(target);
            profile.setCombatUntilMillis(until);
            profile.setFollowTarget(null);
        }
    }

    private void handleTroopHunt(Player player, TroopProfile troop, String message, String lower) {
        String tail = message.substring(lower.indexOf("matem pra mim ") + "matem pra mim ".length()).trim();
        if (tail.isBlank()) {
            player.sendMessage(color("&eUso: <tropa> matem pra mim <quantidade> <mob>"));
            return;
        }

        String[] parts = tail.split("\\s+", 2);
        int count = 1;
        String mobName;
        try {
            count = Integer.parseInt(parts[0]);
            mobName = parts.length > 1 ? parts[1].trim() : "";
        } catch (NumberFormatException ex) {
            mobName = tail;
        }

        if (mobName.isBlank()) {
            player.sendMessage(color("&eInforme o mob."));
            return;
        }

        EntityType type = resolveMobType(mobName);
        if (type == null) {
            player.sendMessage(color("&eNão reconheci esse mob."));
            return;
        }

        List<LivingEntity> mobs = new ArrayList<>();
        for (Entity entity : player.getWorld().getNearbyEntities(player.getLocation(), 40, 40, 40)) {
            if (mobs.size() >= count) break;
            if (entity instanceof LivingEntity living && entity.getType() == type) {
                mobs.add(living);
            }
        }

        if (mobs.isEmpty()) {
            player.sendMessage(color("&eNão achei nenhum " + mobName + " perto."));
            return;
        }

        int i = 0;
        for (UUID npcId : troop.members()) {
            if (i >= mobs.size()) break;
            LifeSteveProfile profile = profiles.get(npcId);
            if (profile == null) continue;
            profile.setCombatTarget(mobs.get(i).getUniqueId());
            profile.setCombatUntilMillis(System.currentTimeMillis() + (getConfig().getLong("life-steve.command-duration-seconds", 60L) * 1000L));
            profile.setFollowTarget(null);
            i++;
        }
        saveProfiles();
        player.sendMessage(color("&aA tropa " + troop.name() + " vai matar " + mobs.size() + " " + mobName + "."));
    }

    private EntityType resolveMobType(String input) {
        String v = input.toLowerCase(Locale.ROOT).replace(" ", "_");
        return switch (v) {
            case "zumbi", "zombie" -> EntityType.ZOMBIE;
            case "esqueleto", "skeleton" -> EntityType.SKELETON;
            case "creeper" -> EntityType.CREEPER;
            case "aranha", "spider" -> EntityType.SPIDER;
            case "enderman" -> EntityType.ENDERMAN;
            case "bruxa", "witch" -> EntityType.WITCH;
            case "slime" -> EntityType.SLIME;
            case "blaze" -> EntityType.BLAZE;
            case "pillager", "pilhador" -> EntityType.PILLAGER;
            case "hoglin" -> EntityType.HOGLIN;
            case "piglin" -> EntityType.PIGLIN;
            case "warden" -> EntityType.WARDEN;
            default -> {
                try {
                    yield EntityType.valueOf(v.toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException ex) {
                    yield null;
                }
            }
        };
    }

    private Player findOnlinePlayer(String name) {
        if (name == null || name.isBlank()) return null;
        String q = name.toLowerCase(Locale.ROOT);
        for (Player online : Bukkit.getOnlinePlayers()) {
            String on = online.getName().toLowerCase(Locale.ROOT);
            if (on.equals(q) || on.contains(q)) return online;
        }
        return null;
    }

    private List<LifeSteveProfile> nearbyOwnedProfiles(Location origin, UUID owner, double radius) {
        double radiusSq = radius * radius;
        List<LifeSteveProfile> out = new ArrayList<>();
        for (LifeSteveProfile profile : profiles.values()) {
            if (profile.owner() == null || !profile.owner().equals(owner)) continue;
            NPC npc = npcById(profile.npcId());
            if (npc == null || !npc.isSpawned() || npc.getEntity() == null) continue;
            if (npc.getEntity().getLocation().distanceSquared(origin) <= radiusSq) {
                out.add(profile);
            }
        }
        return out;
    }

    private LivingEntity findNearestTarget(Location origin, double radius, UUID ignoreOwner) {
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        World world = origin.getWorld();
        if (world == null) return null;
        for (Entity entity : world.getNearbyEntities(origin, radius, radius, radius)) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity.getUniqueId().equals(ignoreOwner)) continue;
            if (living.isDead()) continue;
            double dist = living.getLocation().distanceSquared(origin);
            if (dist < bestDist) {
                best = living;
                bestDist = dist;
            }
        }
        return best;
    }

    private void tickLifeSteves() {
        if (!hasCitizens()) return;
        long now = System.currentTimeMillis();

        for (LifeSteveProfile profile : profiles.values()) {
            NPC npc = npcById(profile.npcId());
            if (npc == null || !npc.isSpawned() || !(npc.getEntity() instanceof LivingEntity living)) continue;

            setMaxHealth(living, getConfig().getDouble("life-steve.max-health", 40.0));
            profile.setLocation(living.getLocation());

            if (getConfig().getBoolean("life-steve.auto-equip-armor", true)) {
                autoEquipBestArmor(profile);
                applyEquipment(npc, profile);
            }

            Player followPlayer = null;
            if (profile.followTarget() != null && profile.followUntilMillis() > now) {
                Entity entity = Bukkit.getEntity(profile.followTarget());
                if (entity instanceof Player p && p.isOnline()) {
                    followPlayer = p;
                } else {
                    profile.setFollowTarget(null);
                }
            }

            Player owner = profile.owner() == null ? null : Bukkit.getPlayer(profile.owner());
            if (followPlayer == null && owner != null && owner.isOnline()) followPlayer = owner;

            if (followPlayer != null && followPlayer.getWorld().equals(living.getWorld())) {
                double dist = living.getLocation().distanceSquared(followPlayer.getLocation());
                double follow = getConfig().getDouble("life-steve.follow-distance", 5.0);
                double teleport = getConfig().getDouble("life-steve.teleport-distance", 64.0);
                if (dist > teleport * teleport) {
                    living.teleport(followPlayer.getLocation().clone().add(1, 0, 1));
                } else if (dist > follow * follow) {
                    npc.getNavigator().getLocalParameters().baseSpeed((float) getConfig().getDouble("life-steve.base-speed", 0.24));
                    npc.getNavigator().setTarget(followPlayer.getLocation());
                } else {
                    npc.getNavigator().cancelNavigation();
                }
                faceTarget(living, followPlayer.getLocation());
            } else {
                wander(npc, living, profile);
            }

            UUID targetId = profile.combatTarget();
            if (targetId != null && profile.combatUntilMillis() > now) {
                Entity entity = Bukkit.getEntity(targetId);
                if (entity instanceof LivingEntity target && !target.isDead() && target.getWorld().equals(living.getWorld())) {
                    handleCombat(npc, living, profile, target, now);
                    continue;
                }
                profile.setCombatTarget(null);
            }
        }
    }

    private void faceTarget(LivingEntity living, Location target) {
        Location loc = living.getLocation();
        Vector dir = target.toVector().subtract(loc.toVector());
        if (dir.lengthSquared() <= 0.0001) return;
        loc.setDirection(dir);
        living.teleport(loc);
    }

    private void handleCombat(NPC npc, LivingEntity living, LifeSteveProfile profile, LivingEntity target, long now) {
        double range = getConfig().getDouble("life-steve.attack-range", 2.8);
        double dist = living.getLocation().distanceSquared(target.getLocation());
        double rangeSq = range * range;

        if (dist > rangeSq) {
            npc.getNavigator().getLocalParameters().baseSpeed((float) getConfig().getDouble("life-steve.base-speed", 0.24) * 1.2f);
            npc.getNavigator().setTarget(target.getLocation());
            faceTarget(living, target.getLocation());
            if (profile.combatStyle() == CombatStyle.SPEAR && dist > 6.0) {
                Vector dash = target.getLocation().toVector().subtract(living.getLocation().toVector()).normalize().multiply(0.65);
                dash.setY(0.15);
                living.setVelocity(dash);
            }
            return;
        }

        long cooldown = getConfig().getLong("life-steve.attack-cooldown-ms", 800L);
        if (now - profile.lastAttackMillis() < cooldown) return;
        profile.setLastAttackMillis(now);

        faceTarget(living, target.getLocation());

        switch (profile.combatStyle()) {
            case CLUB -> {
                Vector leap = target.getLocation().toVector().subtract(living.getLocation().toVector()).normalize().multiply(0.32);
                leap.setY(0.90);
                living.setVelocity(leap);
                target.damage(getConfig().getDouble("life-steve.attack-damage", 4.0) + 2.0, living);
                living.getWorld().spawnParticle(Particle.CLOUD, target.getLocation().add(0, 1, 0), 14, 0.25, 0.2, 0.25, 0.05);
            }
            case SPEAR -> {
                Vector dash = target.getLocation().toVector().subtract(living.getLocation().toVector()).normalize().multiply(0.72);
                dash.setY(0.18);
                living.setVelocity(dash);
                target.damage(getConfig().getDouble("life-steve.attack-damage", 4.0) + 1.0, living);
                living.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 12, 0.2, 0.2, 0.2, 0.08);
            }
            case MELEE -> {
                target.damage(getConfig().getDouble("life-steve.attack-damage", 4.0), living);
                living.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 8, 0.15, 0.15, 0.15, 0.06);
            }
        }
    }

    private void wander(NPC npc, LivingEntity living, LifeSteveProfile profile) {
        Location home = profile.getLocation() != null ? profile.getLocation() : living.getLocation();
        if (home.getWorld() == null || !home.getWorld().equals(living.getWorld())) return;

        if (living.getLocation().distanceSquared(home) > 144.0) {
            npc.getNavigator().getLocalParameters().baseSpeed((float) getConfig().getDouble("life-steve.base-speed", 0.24));
            npc.getNavigator().setTarget(home);
            return;
        }

        if (ThreadLocalRandom.current().nextDouble() < 0.2) {
            Location wanderTarget = home.clone().add(ThreadLocalRandom.current().nextDouble(-5, 5), 0, ThreadLocalRandom.current().nextDouble(-5, 5));
            npc.getNavigator().getLocalParameters().baseSpeed((float) getConfig().getDouble("life-steve.base-speed", 0.24));
            npc.getNavigator().setTarget(wanderTarget);
            faceTarget(living, wanderTarget);
        }
    }

    private void autoEquipBestArmor(LifeSteveProfile profile) {
        ItemStack[] storage = profile.storage();
        int[] armorSlots = {36, 37, 38, 39};

        for (int armorSlot : armorSlots) {
            int bestIndex = findBestArmorIndex(storage, armorSlot);
            if (bestIndex == -1) continue;

            ItemStack candidate = storage[bestIndex];
            ItemStack current = storage[armorSlot];
            if (armorScore(candidate) > armorScore(current)) {
                storage[armorSlot] = candidate;
                storage[bestIndex] = current;
            }
        }
    }

    private int findBestArmorIndex(ItemStack[] storage, int armorSlot) {
        int bestIndex = -1;
        int bestScore = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack item = storage[i];
            if (!isArmorForSlot(item, armorSlot)) continue;
            int score = armorScore(item);
            if (score > bestScore) {
                bestScore = score;
                bestIndex = i;
            }
        }
        return bestIndex;
    }

    private boolean isArmorForSlot(ItemStack item, int armorSlot) {
        if (item == null || item.getType().isAir()) return false;
        String type = item.getType().name();
        return switch (armorSlot) {
            case 36 -> type.endsWith("HELMET") || type.equals("TURTLE_HELMET");
            case 37 -> type.endsWith("CHESTPLATE");
            case 38 -> type.endsWith("LEGGINGS");
            case 39 -> type.endsWith("BOOTS");
            default -> false;
        };
    }

    private int armorScore(ItemStack item) {
        if (item == null || item.getType().isAir()) return 0;
        String type = item.getType().name();
        int base = 0;
        if (type.contains("NETHERITE")) base = 500;
        else if (type.contains("DIAMOND")) base = 400;
        else if (type.contains("IRON")) base = 300;
        else if (type.contains("CHAINMAIL")) base = 200;
        else if (type.contains("GOLDEN")) base = 180;
        else if (type.contains("TURTLE")) base = 220;
        else if (type.contains("LEATHER")) base = 100;

        ItemMeta meta = item.getItemMeta();
        int bonus = 0;
        if (meta != null && meta.hasEnchant(org.bukkit.enchantments.Enchantment.PROTECTION_ENVIRONMENTAL)) {
            bonus += meta.getEnchantLevel(org.bukkit.enchantments.Enchantment.PROTECTION_ENVIRONMENTAL) * 20;
        }
        if (meta != null && meta.hasEnchant(org.bukkit.enchantments.Enchantment.PROTECTION_EXPLOSIONS)) {
            bonus += meta.getEnchantLevel(org.bukkit.enchantments.Enchantment.PROTECTION_EXPLOSIONS) * 15;
        }
        return base + bonus;
    }

    private void applyEquipment(NPC npc, LifeSteveProfile profile) {
        if (!(npc.getEntity() instanceof Player player)) return;
        ItemStack[] storage = profile.storage();
        ItemStack[] inv = new ItemStack[36];
        System.arraycopy(storage, 0, inv, 0, 36);
        player.getInventory().setContents(inv);
        player.getInventory().setHelmet(storage[36]);
        player.getInventory().setChestplate(storage[37]);
        player.getInventory().setLeggings(storage[38]);
        player.getInventory().setBoots(storage[39]);
    }

    private void openInventory(Player player, LifeSteveProfile profile) {
        LifeSteveInventoryHolder holder = new LifeSteveInventoryHolder(profile.npcId());
        Inventory inventory = Bukkit.createInventory(holder, 45, "LifeSteve: " + profile.nameOrId());
        holder.setInventory(inventory);
        inventory.setContents(profile.storage());
        player.openInventory(inventory);
        player.sendMessage(color("&7Abrindo inventário de &f" + profile.nameOrId() + "&7."));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof LifeSteveInventoryHolder holder)) return;
        NPC npc = npcById(holder.npcId());
        if (npc == null) return;

        LifeSteveProfile profile = profileFor(npc);
        ItemStack[] contents = event.getInventory().getContents();
        ItemStack[] storage = profile.storage();
        for (int i = 0; i < storage.length && i < contents.length; i++) {
            storage[i] = contents[i];
        }
        profile.touch("Inventário editado", getConfig().getInt("life-steve.memory-limit", 30));
        autoEquipBestArmor(profile);
        applyEquipment(npc, profile);
        saveProfiles();
    }

    private void startBuild(Player player, LifeSteveProfile profile) {
        if (!hasCitizens()) {
            player.sendMessage(color("&cCitizens não está ativo."));
            return;
        }
        if (buildTasks.containsKey(profile.npcId())) {
            player.sendMessage(color("&eEste LifeSteve já está construindo."));
            return;
        }
        NPC npc = npcById(profile.npcId());
        if (npc == null || !npc.isSpawned() || npc.getEntity() == null) {
            player.sendMessage(color("&cNPC não encontrado."));
            return;
        }

        File npcBuildDir = new File(buildsRoot, profile.npcId().toString());
        npcBuildDir.mkdirs();
        File schematic = findSchematic(npcBuildDir);
        if (schematic == null) {
            player.sendMessage(color("&cNenhuma schematic encontrada em &f" + npcBuildDir.getPath()));
            return;
        }

        int durationSeconds = getConfig().getInt("life-steve.build-duration-seconds", 30);
        Location origin = npc.getEntity().getLocation().clone();
        BukkitTask task = new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (!npc.isSpawned() || npc.getEntity() == null) {
                    cancel();
                    buildTasks.remove(profile.npcId());
                    return;
                }

                if (elapsed >= durationSeconds * 20) {
                    cancel();
                    buildTasks.remove(profile.npcId());
                    pasteSchematic(origin, schematic);
                    profile.touch("Construção concluída: " + schematic.getName(), getConfig().getInt("life-steve.memory-limit", 30));
                    saveProfiles();
                    return;
                }

                spinAndSmoke(npc.getEntity(), elapsed);
                elapsed += 10;
            }
        }.runTaskTimer(this, 0L, 10L);

        buildTasks.put(profile.npcId(), task);
        player.sendMessage(color("&a" + profile.nameOrId() + " começou a construir."));
    }

    private File findSchematic(File npcBuildDir) {
        File named = new File(npcBuildDir, "build.schem");
        if (named.isFile()) return named;
        File[] files = npcBuildDir.listFiles((dir, name) -> name.endsWith(".schem") || name.endsWith(".schematic"));
        if (files == null || files.length == 0) return null;
        List<File> sorted = new ArrayList<>(List.of(files));
        sorted.sort(Comparator.comparing(File::getName));
        return sorted.get(0);
    }

    private void spinAndSmoke(org.bukkit.entity.Entity entity, int ticks) {
        Location loc = entity.getLocation().clone();
        float newYaw = loc.getYaw() + 30f;
        loc.setYaw(newYaw);
        entity.teleport(loc);

        World world = loc.getWorld();
        if (world == null) return;

        double radius = 1.2;
        double angle = Math.toRadians(ticks * 18.0);
        double x = loc.getX() + Math.cos(angle) * radius;
        double z = loc.getZ() + Math.sin(angle) * radius;
        Location point = new Location(world, x, loc.getY() + 1.0, z);
        world.spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, point, 8, 0.12, 0.18, 0.12, 0.02);
    }

    private void pasteSchematic(Location origin, File schematicFile) {
        World world = origin.getWorld();
        if (world == null) return;

        ClipboardFormat format = ClipboardFormats.findByFile(schematicFile);
        if (format == null) {
            getLogger().warning("Formato de schematic não reconhecido: " + schematicFile.getName());
            return;
        }

        try (ClipboardReader reader = format.getReader(new FileInputStream(schematicFile))) {
            Clipboard clipboard = reader.read();
            try (EditSession editSession = WorldEdit.getInstance().newEditSession(BukkitAdapter.adapt(world))) {
                Operation operation = new ClipboardHolder(clipboard)
                        .createPaste(editSession)
                        .to(BlockVector3.at(origin.getBlockX(), origin.getBlockY(), origin.getBlockZ()))
                        .ignoreAirBlocks(false)
                        .build();
                Operations.complete(operation);
            }
        } catch (Exception e) {
            getLogger().severe("Erro ao colar schematic: " + e.getMessage());
        }
    }

    private void applyName(LifeSteveProfile profile, NPC npc) {
        String formatted = formatName(profile);
        npc.setName(formatted);
        if (npc.getEntity() instanceof LivingEntity living) {
            living.setCustomName(formatted);
            living.setCustomNameVisible(true);
        }
    }

    private void applyNameFromCommand(Player player, LifeSteveProfile profile, String newName) {
        profile.setDisplayName(newName);
        profile.touch("Renomeado para " + newName, getConfig().getInt("life-steve.memory-limit", 30));
        NPC npc = npcById(profile.npcId());
        if (npc != null) applyName(profile, npc);
        saveProfiles();
        player.sendMessage(color("&aNome alterado para &f" + newName + "&a."));
    }

    private void applySkinCommand(Player player, LifeSteveProfile profile, String skinName) {
        profile.setSkin(skinName);
        ensureNpcFolders(profile.npcId());
        File skinFile = new File(new File(skinsRoot, profile.npcId().toString()), "skin.txt");
        try {
            Files.writeString(skinFile.toPath(), skinName, StandardCharsets.UTF_8);
        } catch (IOException e) {
            player.sendMessage(color("&cNão foi possível salvar a skin."));
            return;
        }
        NPC npc = npcById(profile.npcId());
        if (npc != null) applySkin(npc, profile);
        saveProfiles();
        player.sendMessage(color("&aSkin definida para &f" + skinName + "&a."));
    }

    private void applyPersonality(Player player, LifeSteveProfile profile, Personality personality) {
        profile.setPersonality(personality);
        profile.touch("Personalidade alterada para " + personality.label(), getConfig().getInt("life-steve.memory-limit", 30));
        saveProfiles();
        player.sendMessage(color("&aPersonalidade definida para &f" + personality.label() + "&a."));
    }

    private void stopNpc(LifeSteveProfile profile) {
        profile.setFollowTarget(null);
        profile.setFollowUntilMillis(0L);
        profile.setCombatTarget(null);
        profile.setCombatUntilMillis(0L);
        NPC npc = npcById(profile.npcId());
        if (npc != null && npc.isSpawned()) {
            npc.getNavigator().cancelNavigation();
        }
    }

    private void stopTroop(TroopProfile troop) {
        for (UUID npcId : troop.members()) {
            LifeSteveProfile profile = profiles.get(npcId);
            if (profile != null) {
                stopNpc(profile);
            }
        }
    }

    private boolean handleTroopCommand(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(color("&cUso: /tropa <nome-da-tropa> <nomeNpc1> <nomeNpc2> ..."));
            return true;
        }

        String troopName = args[0].trim();
        List<LifeSteveProfile> selected = new ArrayList<>();

        for (int i = 1; i < args.length; i++) {
            LifeSteveProfile match = findNpcByName(args[i]);
            if (match != null && !selected.contains(match)) {
                selected.add(match);
            }
        }

        if (selected.isEmpty()) {
            sender.sendMessage(color("&cNão achei nenhum NPC com esses nomes."));
            return true;
        }

        for (LifeSteveProfile profile : selected) {
            profile.setTroopName(troopName);
            profile.touch("Entrou na tropa " + troopName, getConfig().getInt("life-steve.memory-limit", 30));
            NPC npc = npcById(profile.npcId());
            if (npc != null) applyName(profile, npc);
        }

        saveProfiles();
        sender.sendMessage(color("&aTropa &f" + troopName + " &acriada/atualizada com &f" + selected.size() + " &anpc(s)."));
        return true;
    }

    private LifeSteveProfile findNpcByName(String query) {
        if (query == null || query.isBlank()) return null;
        String q = query.toLowerCase(Locale.ROOT);
        for (LifeSteveProfile profile : sortedProfilesByNameLength()) {
            String name = stripTroopPrefix(profile.displayName()).toLowerCase(Locale.ROOT);
            String troop = profile.troopName().toLowerCase(Locale.ROOT);
            if (name.equals(q) || name.contains(q) || profile.npcId().toString().startsWith(q)) return profile;
            if (!troop.isBlank() && troop.contains(q)) return profile;
        }
        return null;
    }

    private LifeSteveProfile nearestProfile(Location origin, double radius) {
        double radiusSq = radius * radius;
        LifeSteveProfile best = null;
        double bestDist = Double.MAX_VALUE;
        for (LifeSteveProfile profile : profiles.values()) {
            NPC npc = npcById(profile.npcId());
            if (npc == null || !npc.isSpawned() || npc.getEntity() == null) continue;
            double dist = npc.getEntity().getLocation().distanceSquared(origin);
            if (dist <= radiusSq && dist < bestDist) {
                best = profile;
                bestDist = dist;
            }
        }
        return best;
    }

    private List<LifeSteveProfile> sortedProfilesByNameLength() {
        List<LifeSteveProfile> list = new ArrayList<>(profiles.values());
        list.sort((a, b) -> Integer.compare(stripTroopPrefix(b.displayName()).length(), stripTroopPrefix(a.displayName()).length()));
        return list;
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private void startStopByCommand(Player player, LifeSteveProfile profile) {
        stopNpc(profile);
        saveProfiles();
        player.sendMessage(color("&a" + profile.nameOrId() + " parou de seguir."));
    }

    private void startStopNearby(Player player) {
        LifeSteveProfile nearest = nearestProfile(player.getLocation(), 8.0);
        if (nearest == null) {
            player.sendMessage(color("&cNenhum LifeSteve perto de você."));
            return;
        }
        startStopByCommand(player, nearest);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("tropa")) {
            return handleTroopCommand(sender, args);
        }

        if (command.getName().equalsIgnoreCase("rn")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(color("&cUse este comando dentro do jogo."));
                return true;
            }
            if (args.length < 2 || !args[0].equalsIgnoreCase("lifesteve")) {
                player.sendMessage(color("&eUso: /rn lifesteve <nome>"));
                return true;
            }
            LifeSteveProfile nearest = nearestProfile(player.getLocation(), 6.0);
            if (nearest == null) {
                player.sendMessage(color("&cNenhum LifeSteve perto de você."));
                return true;
            }
            String newName = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)).trim();
            if (newName.isBlank()) {
                player.sendMessage(color("&eInforme um nome válido."));
                return true;
            }
            applyNameFromCommand(player, nearest, newName);
            return true;
        }

        if (!command.getName().equalsIgnoreCase("lifesteves")) return false;

        if (args.length == 0) {
            sender.sendMessage(color("&7/lifesteves reload &7| &7list &7| &7inv &7| &7skin <nome> &7| &7style <clava|lança|corpo> &7| &7name <novo nome> &7| &7perso <nome> &7| &7build &7| &7stop"));
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                reloadConfig();
                setupFolders();
                loadProfiles();
                sender.sendMessage(color("&aLifeStevesCore recarregado."));
                return true;
            }
            case "list" -> {
                sender.sendMessage(color("&eLifeSteves: &f" + profiles.values().stream().map(LifeSteveProfile::nameOrId).reduce((a, b) -> a + ", " + b).orElse("nenhum")));
                return true;
            }
            case "inv" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cUse este comando dentro do jogo."));
                    return true;
                }
                LifeSteveProfile nearest = nearestProfile(player.getLocation(), 6.0);
                if (nearest == null) {
                    player.sendMessage(color("&cNenhum LifeSteve perto de você."));
                    return true;
                }
                NPC npc = npcById(nearest.npcId());
                if (npc == null) {
                    player.sendMessage(color("&cNPC não encontrado."));
                    return true;
                }
                openInventory(player, nearest);
                return true;
            }
            case "skin" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cUse este comando dentro do jogo."));
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(color("&eUso: /lifesteves skin <nome>"));
                    return true;
                }
                LifeSteveProfile nearest = nearestProfile(player.getLocation(), 6.0);
                if (nearest == null) {
                    player.sendMessage(color("&cNenhum LifeSteve perto de você."));
                    return true;
                }
                applySkinCommand(player, nearest, args[1]);
                return true;
            }
            case "style" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cUse este comando dentro do jogo."));
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(color("&eUso: /lifesteves style <clava|lança|corpo>"));
                    return true;
                }
                LifeSteveProfile nearest = nearestProfile(player.getLocation(), 6.0);
                if (nearest == null) {
                    player.sendMessage(color("&cNenhum LifeSteve perto de você."));
                    return true;
                }
                nearest.setCombatStyle(CombatStyle.fromString(args[1]));
                nearest.touch("Estilo alterado", getConfig().getInt("life-steve.memory-limit", 30));
                saveProfiles();
                player.sendMessage(color("&aEstilo definido para &f" + nearest.combatStyle().name().toLowerCase(Locale.ROOT) + "&a."));
                return true;
            }
            case "name" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cUse este comando dentro do jogo."));
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(color("&eUso: /lifesteves name <novo nome>"));
                    return true;
                }
                LifeSteveProfile nearest = nearestProfile(player.getLocation(), 6.0);
                if (nearest == null) {
                    player.sendMessage(color("&cNenhum LifeSteve perto de você."));
                    return true;
                }
                String display = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)).trim();
                applyNameFromCommand(player, nearest, display);
                return true;
            }
            case "perso" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cUse este comando dentro do jogo."));
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(color("&eUso: /lifesteves perso <Raivoso|Amigável|Carinhoso|Quieto|Depressivo|Alegre|Confuso>"));
                    return true;
                }
                LifeSteveProfile nearest = nearestProfile(player.getLocation(), 6.0);
                if (nearest == null) {
                    player.sendMessage(color("&cNenhum LifeSteve perto de você."));
                    return true;
                }
                applyPersonality(player, nearest, Personality.fromString(args[1]));
                return true;
            }
            case "build" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cUse este comando dentro do jogo."));
                    return true;
                }
                LifeSteveProfile nearest = nearestProfile(player.getLocation(), 8.0);
                if (nearest == null) {
                    player.sendMessage(color("&cNenhum LifeSteve perto de você."));
                    return true;
                }
                startBuild(player, nearest);
                return true;
            }
            case "stop" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cUse este comando dentro do jogo."));
                    return true;
                }
                startStopNearby(player);
                return true;
            }
            default -> {
                sender.sendMessage(color("&cUso: /lifesteves reload | list | inv | skin <nome> | style <clava|lança|corpo> | name <novo nome> | perso <nome> | build | stop"));
                return true;
            }
        }
    }

    private boolean containsAffection(String lower) {
        return lower.contains("carinho") || lower.contains("querido") || lower.contains("amigo") || lower.contains("amo") || lower.contains("obrigado") || lower.contains("bonito") || lower.contains("fofo") || lower.contains("legal");
    }

    private static final class LifeSteveInventoryHolder implements InventoryHolder {
        private final UUID npcId;
        private Inventory inventory;

        private LifeSteveInventoryHolder(UUID npcId) {
            this.npcId = npcId;
        }

        public UUID npcId() { return npcId; }
        public void setInventory(Inventory inventory) { this.inventory = inventory; }
        @Override public Inventory getInventory() { return inventory; }
    }
}
