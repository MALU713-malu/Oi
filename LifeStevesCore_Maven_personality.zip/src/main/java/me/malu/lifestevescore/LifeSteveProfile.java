package me.malu.lifestevescore;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public final class LifeSteveProfile {
    private final UUID npcId;
    private UUID owner;
    private String displayName = "LifeSteve";
    private String troopName = "";
    private String skin = "";
    private Personality personality = Personality.random();
    private int affectionPoints = 0;
    private double health = 40.0;
    private int hunger = 20;
    private String emotion = "neutral";
    private Location location;
    private final List<String> memory = new ArrayList<>();
    private final ItemStack[] storage = new ItemStack[45];
    private CombatStyle combatStyle = CombatStyle.MELEE;
    private UUID followTarget;
    private long followUntilMillis;
    private UUID combatTarget;
    private long combatUntilMillis;
    private long lastAttackMillis;

    public LifeSteveProfile(UUID npcId) {
        this.npcId = npcId;
    }

    public static LifeSteveProfile fromSection(UUID npcId, ConfigurationSection section) {
        LifeSteveProfile profile = new LifeSteveProfile(npcId);

        String owner = section.getString("owner", "");
        if (!owner.isBlank()) {
            try { profile.owner = UUID.fromString(owner); } catch (IllegalArgumentException ignored) {}
        }

        profile.displayName = section.getString("displayName", "LifeSteve");
        profile.troopName = section.getString("troopName", "");
        profile.skin = section.getString("skin", "");
        profile.personality = Personality.fromString(section.getString("personality", ""));
        profile.affectionPoints = section.getInt("affectionPoints", 0);
        profile.health = section.getDouble("health", 40.0);
        profile.hunger = section.getInt("hunger", 20);
        profile.emotion = section.getString("emotion", "neutral");
        profile.location = section.getLocation("location");
        profile.combatStyle = CombatStyle.fromString(section.getString("combatStyle", "melee"));

        String follow = section.getString("followTarget", "");
        if (!follow.isBlank()) {
            try { profile.followTarget = UUID.fromString(follow); } catch (IllegalArgumentException ignored) {}
        }
        profile.followUntilMillis = section.getLong("followUntilMillis", 0L);

        String combat = section.getString("combatTarget", "");
        if (!combat.isBlank()) {
            try { profile.combatTarget = UUID.fromString(combat); } catch (IllegalArgumentException ignored) {}
        }
        profile.combatUntilMillis = section.getLong("combatUntilMillis", 0L);
        profile.lastAttackMillis = section.getLong("lastAttackMillis", 0L);

        profile.memory.addAll(section.getStringList("memory"));

        Object rawStorage = section.get("storage");
        if (rawStorage instanceof List<?> list) {
            for (int i = 0; i < Math.min(list.size(), profile.storage.length); i++) {
                Object entry = list.get(i);
                if (entry instanceof ItemStack item) profile.storage[i] = item;
            }
        }

        return profile;
    }

    public void save(ConfigurationSection section) {
        section.set("owner", owner == null ? "" : owner.toString());
        section.set("displayName", displayName);
        section.set("troopName", troopName);
        section.set("skin", skin);
        section.set("personality", personality.name());
        section.set("affectionPoints", affectionPoints);
        section.set("health", health);
        section.set("hunger", hunger);
        section.set("emotion", emotion);
        section.set("location", location);
        section.set("combatStyle", combatStyle.name());
        section.set("followTarget", followTarget == null ? "" : followTarget.toString());
        section.set("followUntilMillis", followUntilMillis);
        section.set("combatTarget", combatTarget == null ? "" : combatTarget.toString());
        section.set("combatUntilMillis", combatUntilMillis);
        section.set("lastAttackMillis", lastAttackMillis);
        section.set("memory", memory);
        section.set("storage", Arrays.asList(storage));
    }

    public UUID npcId() { return npcId; }
    public UUID owner() { return owner; }
    public void setOwner(UUID owner) { this.owner = owner; }
    public String displayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public String troopName() { return troopName; }
    public void setTroopName(String troopName) { this.troopName = troopName == null ? "" : troopName; }
    public String skin() { return skin; }
    public void setSkin(String skin) { this.skin = skin == null ? "" : skin; }
    public Personality personality() { return personality; }
    public void setPersonality(Personality personality) { this.personality = personality == null ? Personality.random() : personality; }
    public int affectionPoints() { return affectionPoints; }
    public void setAffectionPoints(int affectionPoints) { this.affectionPoints = Math.max(0, affectionPoints); }
    public void addAffectionPoints(int points) { this.affectionPoints = Math.max(0, this.affectionPoints + points); }
    public double getHealth() { return health; }
    public void setHealth(double health) { this.health = health; }
    public int getHunger() { return hunger; }
    public void setHunger(int hunger) { this.hunger = hunger; }
    public String getEmotion() { return emotion; }
    public void setEmotion(String emotion) { this.emotion = emotion; }
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    public CombatStyle combatStyle() { return combatStyle; }
    public void setCombatStyle(CombatStyle combatStyle) { this.combatStyle = combatStyle == null ? CombatStyle.MELEE : combatStyle; }
    public UUID followTarget() { return followTarget; }
    public void setFollowTarget(UUID followTarget) { this.followTarget = followTarget; }
    public long followUntilMillis() { return followUntilMillis; }
    public void setFollowUntilMillis(long followUntilMillis) { this.followUntilMillis = followUntilMillis; }
    public UUID combatTarget() { return combatTarget; }
    public void setCombatTarget(UUID combatTarget) { this.combatTarget = combatTarget; }
    public long combatUntilMillis() { return combatUntilMillis; }
    public void setCombatUntilMillis(long combatUntilMillis) { this.combatUntilMillis = combatUntilMillis; }
    public long lastAttackMillis() { return lastAttackMillis; }
    public void setLastAttackMillis(long lastAttackMillis) { this.lastAttackMillis = lastAttackMillis; }
    public List<String> memory() { return memory; }
    public ItemStack[] storage() { return storage; }

    public void addMemory(String entry, int max) {
        memory.add(entry);
        while (memory.size() > max) memory.remove(0);
    }

    public void touch(String note, int max) {
        addMemory("[" + java.time.Instant.now() + "] " + note, max);
    }

    public String nameOrId() {
        return displayName == null || displayName.isBlank() ? npcId.toString() : displayName;
    }
}
