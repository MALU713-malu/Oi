package me.malu.lifestevescore;

import org.bukkit.plugin.Plugin;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class OpenRouterService {
    private static final Pattern CONTENT_PATTERN = Pattern.compile("\"content\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"", Pattern.DOTALL);
    private final String apiKey;
    private final String baseUrl;
    private final String model;
    private final Plugin plugin;
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    private final Random random = new Random();

    public OpenRouterService(String apiKey, String baseUrl, String model, Plugin plugin) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.baseUrl = (baseUrl == null || baseUrl.isBlank()) ? "https://openrouter.ai/api/v1/chat/completions" : baseUrl.trim();
        this.model = (model == null || model.isBlank()) ? "openai/gpt-4o-mini" : model.trim();
        this.plugin = plugin;
    }

    public String reply(LifeSteveProfile profile, String prompt) {
        if (apiKey.isBlank()) {
            return fallback(profile, prompt);
        }

        String memory = String.join("\n", profile.memory().stream().skip(Math.max(0, profile.memory().size() - 10)).toList());
        String troop = profile.troopName().isBlank() ? "" : "Você pertence à tropa " + profile.troopName() + ".";
        String personality = "Sua personalidade é " + profile.personality().label() + ".";
        String systemPrompt = """
                Você é um NPC vivo de Minecraft.
                Você não lembra de ter morrido e não fala sobre morte ou zumbi antigo.
                Você chama o dono de mestre.
                %s
                %s
                Fale em português do Brasil, de forma natural, com personalidade.
                Responda com 1 a 3 frases, variando a fala.
                Se for útil, faça uma pergunta curta às vezes.
                Memórias recentes:
                %s
                """.formatted(personality, troop, memory.isBlank() ? "(sem memórias)" : memory);

        String body = """
                {
                  "model": "%s",
                  "messages": [
                    {"role": "system", "content": "%s"},
                    {"role": "user", "content": "%s"}
                  ],
                  "temperature": 0.8
                }
                """.formatted(
                escape(model),
                escape(systemPrompt),
                escape(prompt == null ? "" : prompt)
        );

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("HTTP-Referer", "https://openai.com")
                .header("X-Title", "LifeStevesCore")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            String content = extractContent(response.body());
            return (content == null || content.isBlank()) ? fallback(profile, prompt) : content.trim();
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            plugin.getLogger().warning("OpenRouter indisponível: " + e.getMessage());
            return fallback(profile, prompt);
        }
    }

    private String fallback(LifeSteveProfile profile, String prompt) {
        String lower = (prompt == null ? "" : prompt).toLowerCase(Locale.ROOT);
        Personality p = profile.personality();

        if (lower.contains("constru")) return switch (p) {
            case RAIVOSO -> pick("Tá, mestre. Vou fazer.", "Beleza, eu construo.", "Não enrola, eu construo.");
            case AMIGAVEL -> pick("Claro, mestre! Vou construir.", "Pode deixar, mestre.", "Já vou começar, mestre.");
            case CARINHOSO -> pick("Com carinho, mestre. Vou construir.", "Claro, mestre querido.", "Vou fazer isso pra você, mestre.");
            case QUIETO -> pick("Vou construir, mestre.", "Certo, mestre.", "Tá.");
            case DEPRESSIVO -> pick("Tá bom, mestre... vou tentar.", "Se o mestre quer... eu faço.", "Tudo bem, mestre...");
            case ALEGRE -> pick("Eba! Vou construir, mestre!", "Claro, mestre! Vamos lá!", "Estou animado, mestre!");
            case CONFUSO -> pick("Hã... construir? Tá, mestre.", "Acho que eu consigo, mestre.", "Construir, sim. Mestre.");
        };

        if (lower.contains("me siga") || lower.contains("siga") || lower.contains("segue")) return switch (p) {
            case RAIVOSO -> pick("Tá, mestre. Eu vou.", "Fala logo pra onde.", "Vou seguir, mestre.");
            case AMIGAVEL -> pick("Claro, mestre. Estou indo.", "Pode deixar, mestre. Te acompanho.", "Vou com você, mestre.");
            case CARINHOSO -> pick("Sempre, mestre.", "Vou seguir você, mestre.", "Fico com você, mestre.");
            case QUIETO -> pick("Vou, mestre.", "Certo.", "Tá bom, mestre.");
            case DEPRESSIVO -> pick("Tá... eu vou, mestre.", "Se o mestre mandar...", "Eu sigo, mestre.");
            case ALEGRE -> pick("Oba! Vou seguir, mestre!", "Claro! Estou indo com você, mestre!", "Vamos juntos, mestre!");
            case CONFUSO -> pick("Seguir? Ah, sim, mestre.", "Tá, mestre... acho que sim.", "Vou tentar acompanhar, mestre.");
        };

        if (lower.contains("ataqu")) return switch (p) {
            case RAIVOSO -> pick("Finalmente. Vou atacar, mestre.", "Diz quem é e eu derrubo.", "Pode deixar, mestre.");
            case AMIGAVEL -> pick("Entendido, mestre. Vou atacar.", "Claro, mestre. Vou ajudar.", "Já vou pra cima, mestre.");
            case CARINHOSO -> pick("Se for pra ajudar o mestre, eu vou.", "Claro, mestre. Vou proteger você.", "Vou atacar por você, mestre.");
            case QUIETO -> pick("Vou atacar.", "Certo, mestre.", "Entendi.");
            case DEPRESSIVO -> pick("Tá... vou tentar, mestre.", "Se é preciso...", "Vou fazer isso, mestre...");
            case ALEGRE -> pick("Isso! Vou atacar, mestre!", "Pode deixar, mestre!", "Vou com tudo, mestre!");
            case CONFUSO -> pick("Atacar? Tá, mestre.", "Eu vou, acho...", "Certo, mestre.");
        };

        if (lower.contains("mat")) return switch (p) {
            case RAIVOSO -> pick("Vou fazer isso, mestre.", "Diz o alvo e acabou.", "Pode deixar.");
            case AMIGAVEL -> pick("Claro, mestre. Vou cuidar disso.", "Entendido, mestre.", "Vou fazer com calma, mestre.");
            case CARINHOSO -> pick("Se o mestre pediu, eu faço.", "Fica tranquilo, mestre.", "Vou ajudar você.");
            case QUIETO -> pick("Tudo bem.", "Certo, mestre.", "Entendi.");
            case DEPRESSIVO -> pick("Tá... se precisar, eu faço.", "Tudo bem, mestre...", "Vou tentar.");
            case ALEGRE -> pick("Claro! Vou fazer, mestre!", "Com prazer, mestre!", "Deixa comigo, mestre!");
            case CONFUSO -> pick("Matar? Ah... tá, mestre.", "Ok, mestre...?", "Vou tentar, mestre.");
        };

        if (lower.contains("obrigado") || lower.contains("valeu")) return switch (p) {
            case RAIVOSO -> pick("Hum.", "Tanto faz.", "Fiz o que precisava.");
            case AMIGAVEL -> pick("Disponha, mestre.", "Sempre à disposição, mestre.", "Fico feliz em ajudar, mestre.");
            case CARINHOSO -> pick("Sempre por você, mestre.", "Eu gosto de ajudar você, mestre.", "Você é gentil, mestre.");
            case QUIETO -> pick("De nada.", "Certo.", "Hm.");
            case DEPRESSIVO -> pick("De nada, mestre...", "Tanto faz, mas de nada.", "Tá bom, mestre.");
            case ALEGRE -> pick("De nada, mestre!", "Eba, sempre!", "Estou feliz em ajudar, mestre!");
            case CONFUSO -> pick("De nada, mestre... acho.", "Ah, sim.", "Tá.");
        };

        if (lower.contains("oi") || lower.contains("olá") || lower.contains("ola")) return switch (p) {
            case RAIVOSO -> pick("O que foi, mestre?", "Fala.", "Oi. Quer alguma coisa?");
            case AMIGAVEL -> pick("Oi, mestre! Como posso ajudar?", "Olá, mestre.", "Oi! O que manda?");
            case CARINHOSO -> pick("Oi, mestre querido.", "Olá, mestre. Que bom te ver.", "Oi, mestre. Precisa de mim?");
            case QUIETO -> pick("Oi.", "Olá, mestre.", "Hm?");
            case DEPRESSIVO -> pick("Oi, mestre...", "Olá.", "Oi...");
            case ALEGRE -> pick("Opa, mestre!", "Oi oi! Tudo bem, mestre?", "Olá, mestre! Vamos lá?");
            case CONFUSO -> pick("Oi... mestre?", "Olá?", "Hã?");
        };

        if (profile.personality() == Personality.DEPRESSIVO) {
            return pick(
                    "Tá bom, mestre...",
                    "Se precisar, eu faço.",
                    "Certo... mestre.",
                    "Eu vou tentar."
            );
        }

        if (profile.personality() == Personality.QUIETO) {
            return pick("Certo, mestre.", "Entendi.", "Tá.", "Hm.");
        }

        return switch (p) {
            case RAIVOSO -> pick("Fala logo, mestre.", "Tá. O que você quer?", "Diz o que precisa.");
            case AMIGAVEL -> pick("Claro, mestre. O que você precisa?", "Estou ouvindo, mestre.", "Pode falar, mestre.");
            case CARINHOSO -> pick("Sempre, mestre. O que foi?", "Fala comigo, mestre.", "Eu escuto você, mestre.");
            case QUIETO -> pick("Sim.", "Certo, mestre.", "Hm.", "Entendi.");
            case DEPRESSIVO -> pick("Tá bom...", "Entendi, mestre...", "Certo...");
            case ALEGRE -> pick("Eba! O que foi, mestre?", "Manda ver, mestre!", "Pode falar!");
            case CONFUSO -> pick("Hã? Mestre?", "Eu... acho que entendi.", "Pode repetir, mestre?");
        };
    }

    private String pick(String... options) {
        return options[random.nextInt(options.length)];
    }

    private String extractContent(String json) {
        if (json == null || json.isBlank()) return null;
        Matcher matcher = CONTENT_PATTERN.matcher(json);
        if (!matcher.find()) return null;
        return unescape(matcher.group(1));
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    private static String unescape(String s) {
        StringBuilder out = new StringBuilder();
        boolean escape = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (escape) {
                switch (c) {
                    case 'n' -> out.append('\n');
                    case 'r' -> out.append('\r');
                    case 't' -> out.append('\t');
                    case '"' -> out.append('"');
                    case '\\' -> out.append('\\');
                    case 'b' -> out.append('\b');
                    case 'f' -> out.append('\f');
                    default -> out.append(c);
                }
                escape = false;
            } else if (c == '\\') {
                escape = true;
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }
}
