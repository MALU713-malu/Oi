package me.malu.lifestevescore;

public enum CombatStyle {
    CLUB,
    SPEAR,
    MELEE;

    public static CombatStyle fromString(String input) {
        if (input == null) return MELEE;
        String v = input.trim().toLowerCase();
        return switch (v) {
            case "clava", "club" -> CLUB;
            case "lança", "lanca", "spear" -> SPEAR;
            default -> MELEE;
        };
    }
}
