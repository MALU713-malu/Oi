package me.malu.lifestevescore;

import java.util.Locale;
import java.util.Random;

public enum Personality {
    RAIVOSO,
    AMIGAVEL,
    CARINHOSO,
    QUIETO,
    DEPRESSIVO,
    ALEGRE,
    CONFUSO;

    private static final Random RANDOM = new Random();

    public static Personality fromString(String input) {
        if (input == null || input.isBlank()) {
            return random();
        }
        String v = input.trim().toLowerCase(Locale.ROOT)
                .replace('ã', 'a')
                .replace('á', 'a')
                .replace('â', 'a')
                .replace('à', 'a')
                .replace('ç', 'c')
                .replace('é', 'e')
                .replace('ê', 'e')
                .replace('í', 'i')
                .replace('ó', 'o')
                .replace('ô', 'o')
                .replace('õ', 'o')
                .replace('ú', 'u');
        return switch (v) {
            case "raivoso" -> RAIVOSO;
            case "amigavel" -> AMIGAVEL;
            case "carinhoso" -> CARINHOSO;
            case "quieto" -> QUIETO;
            case "depressivo" -> DEPRESSIVO;
            case "alegre" -> ALEGRE;
            case "confuso" -> CONFUSO;
            default -> random();
        };
    }

    public static Personality random() {
        Personality[] values = values();
        return values[RANDOM.nextInt(values.length)];
    }

    public String label() {
        return name().charAt(0) + name().substring(1).toLowerCase(Locale.ROOT);
    }
}
